-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: database
-- Generation Time: Mar 17, 2025 at 03:20 AM
-- Server version: 11.4.3-MariaDB-ubu2404
-- PHP Version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `astudio`
--

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

CREATE TABLE `attributes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `slug` varchar(255) NOT NULL,
  `name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`name`)),
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`description`)),
  `sort_order` mediumint(8) UNSIGNED NOT NULL DEFAULT 0,
  `group` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 0,
  `is_collection` tinyint(1) NOT NULL DEFAULT 0,
  `default` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`id`, `slug`, `name`, `description`, `sort_order`, `group`, `type`, `is_required`, `is_collection`, `default`, `created_at`, `updated_at`) VALUES
(1, 'department', '{\"en\":\"Department\"}', '{\"en\":\"Department that project belongs to.\"}', 1, NULL, 'select', 1, 0, NULL, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, 'start_date', '{\"en\":\"Start date\"}', '{\"en\":\"Project start date.\"}', 2, NULL, 'date', 0, 0, NULL, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, 'end_date', '{\"en\":\"End date\"}', '{\"en\":\"Project end date.\"}', 3, NULL, 'date', 0, 0, NULL, '2025-03-17 01:51:48', '2025-03-17 01:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `attributes_options`
--

CREATE TABLE `attributes_options` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `content` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attributes_options`
--

INSERT INTO `attributes_options` (`id`, `attribute_id`, `content`, `created_at`, `updated_at`) VALUES
(1, 1, 'Software Development (1)', NULL, NULL),
(2, 1, 'Marketing (2)', NULL, NULL),
(3, 1, 'Security (3)', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `attribute_boolean_values`
--

CREATE TABLE `attribute_boolean_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` tinyint(1) NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attribute_datetime_values`
--

CREATE TABLE `attribute_datetime_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` datetime NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attribute_date_values`
--

CREATE TABLE `attribute_date_values` (
  `id` int(10) UNSIGNED NOT NULL,
  `content` date NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_date_values`
--

INSERT INTO `attribute_date_values` (`id`, `content`, `attribute_id`, `entity_type`, `entity_id`, `created_at`, `updated_at`) VALUES
(1, '1992-03-10', 2, 'App\\Models\\Project\\Project', 1, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, '2018-11-15', 3, 'App\\Models\\Project\\Project', 1, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, '1996-04-27', 2, 'App\\Models\\Project\\Project', 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(4, '1986-11-30', 3, 'App\\Models\\Project\\Project', 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(5, '1980-09-30', 2, 'App\\Models\\Project\\Project', 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(6, '2017-07-26', 3, 'App\\Models\\Project\\Project', 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(7, '1982-02-20', 2, 'App\\Models\\Project\\Project', 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(8, '1983-09-05', 3, 'App\\Models\\Project\\Project', 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(9, '1989-10-14', 2, 'App\\Models\\Project\\Project', 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(10, '2017-08-04', 3, 'App\\Models\\Project\\Project', 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(11, '2022-08-07', 2, 'App\\Models\\Project\\Project', 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(12, '1985-03-11', 3, 'App\\Models\\Project\\Project', 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(13, '2017-02-15', 2, 'App\\Models\\Project\\Project', 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(14, '2020-08-15', 3, 'App\\Models\\Project\\Project', 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(15, '1985-09-27', 2, 'App\\Models\\Project\\Project', 8, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(16, '1998-03-01', 3, 'App\\Models\\Project\\Project', 8, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(17, '2014-06-11', 2, 'App\\Models\\Project\\Project', 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(18, '2004-12-02', 3, 'App\\Models\\Project\\Project', 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(19, '2022-11-27', 2, 'App\\Models\\Project\\Project', 10, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(20, '1984-05-16', 3, 'App\\Models\\Project\\Project', 10, '2025-03-17 01:51:48', '2025-03-17 01:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_entity`
--

CREATE TABLE `attribute_entity` (
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) DEFAULT NULL,
  `entity_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_entity`
--

INSERT INTO `attribute_entity` (`attribute_id`, `entity_type`, `entity_id`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\Project\\Project', NULL, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, 'App\\Models\\Project\\Project', NULL, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, 'App\\Models\\Project\\Project', NULL, '2025-03-17 01:51:48', '2025-03-17 01:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_integer_values`
--

CREATE TABLE `attribute_integer_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` int(11) NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attribute_select_values`
--

CREATE TABLE `attribute_select_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` bigint(20) UNSIGNED NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attribute_select_values`
--

INSERT INTO `attribute_select_values` (`id`, `content`, `attribute_id`, `entity_type`, `entity_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'App\\Models\\Project\\Project', 1, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, 2, 1, 'App\\Models\\Project\\Project', 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, 2, 1, 'App\\Models\\Project\\Project', 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(4, 1, 1, 'App\\Models\\Project\\Project', 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(5, 2, 1, 'App\\Models\\Project\\Project', 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(6, 3, 1, 'App\\Models\\Project\\Project', 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(7, 1, 1, 'App\\Models\\Project\\Project', 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(8, 3, 1, 'App\\Models\\Project\\Project', 8, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(9, 2, 1, 'App\\Models\\Project\\Project', 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(10, 1, 1, 'App\\Models\\Project\\Project', 10, '2025-03-17 01:51:48', '2025-03-17 01:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `attribute_text_values`
--

CREATE TABLE `attribute_text_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attribute_varchar_values`
--

CREATE TABLE `attribute_varchar_values` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `content` varchar(255) NOT NULL,
  `attribute_id` bigint(20) UNSIGNED NOT NULL,
  `entity_type` varchar(255) NOT NULL,
  `entity_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('astudio_cache_32afdc911c970ee8684a2447f03cd133d631a8fd', 'i:1;', 1742176387),
('astudio_cache_32afdc911c970ee8684a2447f03cd133d631a8fd:timer', 'i:1742176387;', 1742176387);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2020_01_01_000001_create_attributes_table', 1),
(5, '2020_01_01_000002_create_attribute_text_values_table', 1),
(6, '2020_01_01_000003_create_attribute_boolean_values_table', 1),
(7, '2020_01_01_000004_create_attribute_datetime_values_table', 1),
(8, '2020_01_01_000005_create_attribute_integer_values_table', 1),
(9, '2020_01_01_000006_create_attribute_varchar_values_table', 1),
(10, '2020_01_01_000007_create_attribute_entity_table', 1),
(11, '2020_10_14_000001_add_attribute_value_indexes', 1),
(12, '2025_03_12_181601_create_projects_table', 1),
(13, '2025_03_12_181828_create_project_user_table', 1),
(14, '2025_03_12_181904_create_timesheet_logs_table', 1),
(15, '2025_03_15_000000_create_attribute_date_values_table', 1),
(16, '2025_03_15_000001_create_attribute_options_table', 1),
(17, '2025_03_15_000001_create_attribute_select_values_table', 1),
(18, '2025_03_15_043343_create_oauth_auth_codes_table', 1),
(19, '2025_03_15_043344_create_oauth_access_tokens_table', 1),
(20, '2025_03_15_043345_create_oauth_refresh_tokens_table', 1),
(21, '2025_03_15_043346_create_oauth_clients_table', 1),
(22, '2025_03_15_043347_create_oauth_personal_access_clients_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` uuid NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('b8a231a4ae2301ed041b6056c42ec4704797bc9548f802d3981f78b5ee90051dec8b38fed74b2c5f', 1, '9e733401-b313-4591-bfe7-98d8fdf0934c', NULL, '[]', 0, '2025-03-17 01:52:07', '2025-03-17 01:52:07', '2025-04-01 01:52:07');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` uuid NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` uuid NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
('9e733401-b313-4591-bfe7-98d8fdf0934c', NULL, 'ASTUDIO Password Grant Client', '$2y$10$ptjYJ6wLAtxNYU.kgJDs7.Pnm8LFSQJ456ZZbbfWVksklDhczCKem', 'users', 'http://localhost', 0, 1, 0, '2025-03-17 01:51:49', '2025-03-17 01:51:49');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` uuid NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_refresh_tokens`
--

INSERT INTO `oauth_refresh_tokens` (`id`, `access_token_id`, `revoked`, `expires_at`) VALUES
('63685f3ca4a17fdcd24c53ddbc33e04280201c82f1dde7dcf0f972637908125c0cd869d2d8d7eeff', 'b8a231a4ae2301ed041b6056c42ec4704797bc9548f802d3981f78b5ee90051dec8b38fed74b2c5f', 0, '2025-04-16 01:52:07');

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `status` enum('pending','in-progress','finished','archived') NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Cathryn Simonis', 'in-progress', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, 'Joana Fay', 'in-progress', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, 'Yoshiko Treutel', 'in-progress', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(4, 'Prof. Russ Stracke V', 'archived', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(5, 'Mitchell Sipes', 'finished', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(6, 'Ms. Reyna Smith', 'finished', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(7, 'Osborne Rogahn', 'archived', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(8, 'Mr. Horace Bartoletti I', 'archived', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(9, 'Haylie Gorczany', 'archived', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(10, 'Kaelyn Hand', 'finished', '2025-03-17 01:51:48', '2025-03-17 01:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `project_user`
--

CREATE TABLE `project_user` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'User that is assigned to the referenced `project_id`.',
  `project_id` bigint(20) UNSIGNED NOT NULL COMMENT 'Project to which the user is assigned to.',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `project_user`
--

INSERT INTO `project_user` (`id`, `user_id`, `project_id`, `created_at`, `updated_at`) VALUES
(1, 4, 1, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, 1, 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, 2, 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(4, 4, 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(5, 6, 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(6, 7, 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(7, 9, 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(8, 2, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(9, 3, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(10, 4, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(11, 5, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(12, 6, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(13, 7, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(14, 8, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(15, 9, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(16, 10, 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(17, 1, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(18, 2, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(19, 3, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(20, 4, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(21, 5, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(22, 6, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(23, 7, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(24, 8, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(25, 9, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(26, 10, 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(27, 1, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(28, 2, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(29, 3, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(30, 4, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(31, 7, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(32, 8, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(33, 9, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(34, 10, 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(35, 1, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(36, 3, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(37, 4, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(38, 5, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(39, 7, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(40, 8, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(41, 9, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(42, 10, 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(43, 1, 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(44, 3, 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(45, 4, 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(46, 7, 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(47, 9, 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(48, 10, 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(49, 2, 8, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(50, 3, 8, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(51, 8, 8, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(52, 1, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(53, 2, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(54, 3, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(55, 4, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(56, 5, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(57, 6, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(58, 7, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(59, 9, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(60, 10, 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(61, 1, 10, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(62, 6, 10, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(63, 10, 10, '2025-03-17 01:51:48', '2025-03-17 01:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('nvKHxdzcNg7nbeaRN9HQh26DNsGhkN7oNZE7yu1E', 1, '192.168.32.1', 'PostmanRuntime/7.43.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlBwRUpSb2VIYkhPSFZZckxScFQ3MzdVUE1MT0h0MjlWZDl4YkNTcyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MTA2OiJodHRwOi8vbG9jYWxob3N0L2FwaS92MS90aW1lc2hlZXQvbG9ncz9maWx0ZXIlNUJob3VycyU1RCU1QnZhbHVlJTVEPTUwJmZpbHRlciU1QmhvdXJzJTVEJTVCb3BlcmF0b3IlNUQ9JTNDIjt9fQ==', 1742179493);

-- --------------------------------------------------------

--
-- Table structure for table `timesheet_logs`
--

CREATE TABLE `timesheet_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `project_id` bigint(20) UNSIGNED NOT NULL,
  `task_name` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `hours` double NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `timesheet_logs`
--

INSERT INTO `timesheet_logs` (`id`, `user_id`, `project_id`, `task_name`, `date`, `hours`, `created_at`, `updated_at`) VALUES
(1, 4, 6, 'Ducimus ut sit aut voluptas minus. Explicabo saepe laboriosam repellendus et ipsum enim asperiores. Repudiandae voluptatem iure numquam porro a itaque.', '1986-10-12', 33, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, 2, 8, 'Eligendi officia nostrum magnam sed. Est dolorum amet molestias dolorum quod exercitationem.', '1990-05-16', 42, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, 4, 1, 'Labore sunt voluptatem tempore. Repellendus et sequi modi soluta. Quaerat sit ut reiciendis et.', '2003-08-13', 87, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(4, 7, 9, 'Voluptatem totam quia possimus. Non repellat qui enim dolorem nisi quis in. Sint officia exercitationem aperiam dicta sequi.', '2007-10-26', 77, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(5, 9, 9, 'Qui delectus mollitia aut eligendi doloremque. Vel qui corporis eaque corporis praesentium necessitatibus. Incidunt architecto dolore magni vitae est.', '1979-01-15', 68, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(6, 4, 5, 'Esse voluptates ratione dolores quia est. Ut esse atque omnis in.', '1971-09-24', 53, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(7, 9, 2, 'Earum magnam qui commodi expedita excepturi. Non magnam est doloribus. Sit iste aut dolor voluptatem.', '1992-04-24', 5, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(8, 4, 6, 'Vel voluptatum natus autem nemo necessitatibus. Non sequi sint et inventore.', '2008-09-05', 62, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(9, 4, 1, 'Soluta nam iste quibusdam porro quos similique. Sed aut quis consequatur voluptates omnis sint. Explicabo id perspiciatis consectetur et est.', '1989-05-22', 57, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(10, 4, 1, 'Sed error rerum nihil commodi ut. Dolorum enim sequi architecto quam sint ab laborum. Quaerat quia ratione eum dolores non.', '2020-07-10', 17, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(11, 10, 10, 'Mollitia quo iste aut sed. Sed in tempora maxime amet aut placeat perspiciatis.', '1979-03-08', 37, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(12, 5, 4, 'Exercitationem beatae et animi repudiandae temporibus odit voluptatem. Perferendis repellendus omnis repudiandae.', '1987-10-04', 12, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(13, 9, 2, 'Aliquid numquam et qui sint et beatae et. Qui qui sed dolores. Sed veritatis tempore fugit voluptas facilis et necessitatibus.', '1984-02-17', 63, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(14, 3, 9, 'Voluptatum nihil quia esse voluptas reiciendis temporibus ut. Eius omnis ut voluptatem sint delectus fugit culpa ipsum. Hic enim ab unde molestiae necessitatibus.', '2018-05-29', 37, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(15, 6, 2, 'Non voluptatem labore est ipsam ea. Ea odio ipsa repellat in ut. Ea consequatur molestiae odit illo at eligendi dolorem.', '2024-04-14', 2, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(16, 7, 7, 'Minima quod enim accusamus. Rerum ut minima sed qui minus. Hic libero expedita itaque porro molestiae perferendis.', '2002-11-20', 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(17, 6, 3, 'Ratione consequatur sunt veniam dolores ad. Autem laborum dolorem impedit consequatur ut nobis quia illo. Voluptatum mollitia eligendi est cumque sed non.', '2016-01-24', 33, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(18, 2, 5, 'Omnis dolore quis ut quia repellat harum ut. Ab autem culpa quasi quae.', '1974-09-04', 76, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(19, 1, 6, 'Optio non vero eum dicta et et inventore. Voluptates optio doloribus maxime. Rerum consequatur veniam commodi velit nemo recusandae rerum.', '1997-02-03', 29, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(20, 4, 3, 'Inventore aut voluptatem at qui hic. Nihil illo amet omnis molestiae magni rem reprehenderit. A dolore aspernatur harum cumque facere dolorem et.', '2019-03-20', 96, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(21, 2, 5, 'Reprehenderit in ratione aut aut ullam. Amet laboriosam sunt ut velit maiores.', '2017-01-20', 54, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(22, 4, 9, 'Aspernatur dolor temporibus dolorum facilis. Et voluptatum assumenda et et dolor est sint. Ad eum dolorem non fuga est.', '2012-03-29', 44, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(23, 6, 9, 'Consequatur dolore non eligendi nobis quia expedita. Et voluptatem rerum est.', '1983-05-09', 28, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(24, 3, 5, 'Consectetur voluptas dolores tempora quia vero et nam. Ullam omnis quis deserunt ullam consequuntur vitae quae distinctio. Molestiae earum impedit pariatur.', '1978-04-15', 62, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(25, 1, 4, 'Debitis nihil et quam id. Enim reiciendis eaque sapiente accusamus.', '1997-02-08', 6, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(26, 7, 3, 'Qui vitae velit qui. Et sint consequatur excepturi doloremque. Aliquam laboriosam ut accusamus veritatis.', '1980-09-16', 55, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(27, 10, 6, 'Voluptatibus aut quae quis sit. Soluta aut aut omnis itaque dolores. Nihil ut architecto ipsa.', '2022-10-02', 24, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(28, 5, 3, 'Blanditiis numquam ab est et reiciendis. In nihil rerum vero amet illo rem.', '2000-10-09', 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(29, 9, 7, 'Enim quaerat quis nemo qui id sequi explicabo quos. Fugiat non magni et sunt temporibus et voluptatem accusantium. Quis ullam in ex.', '1995-08-13', 32, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(30, 10, 6, 'Est similique iusto eaque mollitia commodi ut. Architecto qui reprehenderit officiis in est.', '2016-12-13', 90, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(31, 4, 6, 'Sit accusamus porro pariatur nobis. Sunt facere rerum enim consectetur quo quae ullam. Hic rerum est et voluptates sapiente libero.', '1999-04-27', 33, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(32, 4, 1, 'Dignissimos et aliquam quam. Vel fugit provident esse eaque. Deleniti cupiditate consequatur perferendis.', '2006-07-06', 11, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(33, 4, 1, 'Doloremque recusandae in enim et ipsum. Quis qui vero et fuga culpa. Et earum perferendis libero et eligendi.', '2018-09-29', 56, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(34, 7, 3, 'Incidunt voluptatem vero aperiam natus sunt eius et. Deserunt eum est iste ea eligendi quod doloribus eos. Magnam veritatis qui laborum quisquam aspernatur velit.', '2007-01-13', 89, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(35, 10, 6, 'Illo ea quia et facere. Assumenda deleniti ad tempore doloribus illum id. Quam impedit odio voluptatem perspiciatis impedit optio vel.', '2010-11-27', 97, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(36, 9, 6, 'Numquam omnis quis qui ut enim id vero culpa. Illo adipisci qui et in non error. Explicabo exercitationem quam animi et non necessitatibus.', '2022-02-06', 54, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(37, 4, 5, 'Quo ea voluptatem magni quisquam numquam repellat necessitatibus officiis. Ea quas itaque numquam dolorem sequi inventore ad. Nobis aspernatur tempora ad est distinctio quis.', '2011-12-11', 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(38, 4, 1, 'Facere dolorum dolores qui autem iste cupiditate ipsum. Consectetur sit nobis dolores et sequi error quis.', '2019-05-13', 42, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(39, 7, 5, 'Eius autem quidem iste. Qui similique consectetur sunt voluptas est repellat autem. Consectetur nobis ut hic eum aut vero molestias.', '1991-05-24', 27, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(40, 3, 3, 'Sed cupiditate aut eius tempora sunt dolorum eius. Aperiam quos blanditiis a rerum sunt distinctio ipsam.', '2014-11-09', 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(41, 1, 10, 'Iste magnam occaecati reiciendis dignissimos similique alias. Suscipit ad dicta dolore ut quia totam.', '2004-02-19', 22, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(42, 4, 1, 'Asperiores aliquid velit officiis sequi. Dignissimos quam velit molestiae sapiente est repudiandae quia rerum. Voluptatem placeat et sed sed tempore itaque magnam velit.', '2020-08-10', 25, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(43, 7, 7, 'Doloribus quasi nesciunt aut sapiente ipsa numquam similique qui. Ab sed qui voluptatem dolores et. Voluptates nemo doloribus quia esse sunt.', '2023-09-17', 71, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(44, 2, 8, 'Est cum facere est voluptatibus incidunt. Quia qui voluptate autem eos facilis similique vitae. Fuga et alias sit.', '1979-02-24', 30, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(45, 7, 5, 'Similique aut aspernatur quo voluptatem magni. Ipsam et ut consequuntur maxime. Ipsum veritatis nobis veritatis quos sapiente.', '1979-12-21', 8, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(46, 1, 6, 'Voluptatem nobis esse non ipsa. Est et earum culpa et beatae. Nostrum et et vitae velit.', '2010-10-23', 3, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(47, 2, 2, 'Enim blanditiis aspernatur est ut fuga repudiandae. Qui quam quos voluptatem nulla ut.', '1977-12-04', 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(48, 7, 7, 'Eveniet non dolores eos unde molestiae nihil voluptatem. Aliquam qui delectus rerum.', '1979-04-23', 49, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(49, 4, 1, 'Hic non qui ut aperiam nulla nihil. Aut ut ut excepturi quis. Cum ut alias tempore sint sit.', '2021-11-21', 83, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(50, 6, 10, 'Rerum ut exercitationem distinctio ad rem fugit. Ut et et consequuntur aut officia. Aut id dolores assumenda sunt.', '1976-12-22', 1, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(51, 8, 4, 'Id et fuga officiis cupiditate harum. Unde ullam distinctio ut et cum voluptatibus suscipit.', '2000-04-07', 85, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(52, 10, 3, 'Sit ut aut sed alias dolores et nesciunt aliquid. Molestias maxime sed et sit dolorem.', '1978-08-30', 76, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(53, 9, 7, 'Quas consequatur fugiat omnis nobis eos delectus adipisci. Voluptatum ratione deleniti rerum in.', '1985-04-08', 16, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(54, 7, 3, 'Porro explicabo rerum voluptatibus corrupti sunt quo. Repellat facere est voluptatem laudantium exercitationem quia illum.', '1976-07-31', 13, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(55, 3, 8, 'Ab neque similique ex impedit odit tenetur dolor. Alias eveniet aut sit ut debitis veritatis. Aut repellat sapiente autem et nihil aut.', '1973-04-29', 19, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(56, 9, 9, 'Occaecati aliquid earum ipsum perspiciatis sunt consequatur aut. Sed id amet corporis iusto et.', '1975-10-03', 69, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(57, 4, 1, 'Temporibus maxime perspiciatis praesentium perferendis quasi odio in. Error voluptate incidunt ut fuga enim tempore qui.', '2000-09-15', 80, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(58, 1, 5, 'Ea consectetur in suscipit ut. Eos hic perspiciatis possimus labore vero autem delectus et. Fugit et eaque sunt odio.', '1988-11-01', 36, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(59, 4, 7, 'Perspiciatis autem minus enim temporibus. Rerum id numquam maxime dolor. Voluptatem sint eveniet reprehenderit dolor.', '1990-05-16', 94, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(60, 3, 6, 'Commodi dolorum ea et amet quas qui id. Voluptatibus enim cumque consequatur quo corrupti autem.', '1979-06-28', 25, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(61, 1, 9, 'Ut mollitia labore sed. Nemo molestiae ducimus aut amet molestiae quibusdam. Aut repudiandae reiciendis quis saepe et deleniti.', '1997-11-30', 23, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(62, 4, 4, 'Magni architecto laborum maiores aliquid autem. Aut dolore mollitia quae aut autem.', '1977-07-01', 48, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(63, 4, 4, 'Dolor quam explicabo voluptatem officia. Consequuntur natus ullam incidunt.', '2025-02-18', 32, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(64, 1, 10, 'Et et recusandae natus in ratione totam. Sed doloremque et voluptatem repellat ipsa consectetur mollitia. Voluptas assumenda consequatur blanditiis non quam.', '1982-11-18', 27, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(65, 1, 10, 'Molestias et numquam esse aut qui quas nulla. Voluptas id voluptatem laudantium doloremque doloribus voluptatem.', '1979-07-07', 80, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(66, 8, 5, 'Ut ut sed delectus molestiae recusandae vel quam porro. Dolor sequi eum alias amet dolores quibusdam fugiat.', '1985-06-30', 21, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(67, 3, 9, 'Omnis voluptas assumenda non et incidunt est. Velit sunt quos molestias ducimus dolores vero et.', '2021-05-27', 11, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(68, 8, 4, 'Laudantium non libero molestiae nihil. Repellendus maiores voluptatem non. Velit et voluptate quia modi.', '2000-06-20', 89, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(69, 9, 7, 'Consectetur et ut sed quasi. Facilis similique fugit eligendi. Vero dolore quidem architecto et incidunt quos.', '1999-12-08', 62, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(70, 5, 4, 'Mollitia fugiat minima ratione ut laboriosam. Ducimus in molestiae modi omnis commodi.', '1984-10-02', 95, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(71, 3, 5, 'Amet maxime qui nemo et excepturi quisquam est. Rerum reprehenderit cupiditate labore ut nihil. Atque in expedita quam qui magni nihil.', '2002-06-29', 70, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(72, 8, 8, 'Iure nesciunt libero voluptate corporis et sint. Et dignissimos numquam ut et libero laborum qui.', '2019-07-30', 47, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(73, 4, 1, 'Est maxime quos et fugit eaque. Sit atque quo repellat aut quis.', '2021-04-29', 31, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(74, 9, 7, 'Dicta sequi nihil quo optio omnis vitae. Non consequatur blanditiis ipsam commodi ex commodi.', '2014-04-30', 90, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(75, 1, 2, 'Reprehenderit ea distinctio et qui quis unde vero. Eius ipsum aliquid quis aut quia. Laudantium enim fuga excepturi commodi ullam molestiae temporibus.', '2009-10-11', 82, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(76, 2, 4, 'Quia debitis quam consequatur iure corrupti et. Omnis sunt earum nisi.', '1994-10-15', 22, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(77, 6, 10, 'Atque qui perferendis illo aspernatur ea. Aliquam consequatur exercitationem aperiam commodi aperiam blanditiis.', '1985-08-03', 69, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(78, 7, 4, 'Vel repellat enim occaecati et eos qui. Ratione temporibus voluptas dolor consequatur. Ut consequuntur est quas dignissimos vitae qui doloribus.', '2009-04-22', 93, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(79, 4, 6, 'Perspiciatis suscipit consectetur porro ullam. Tenetur rerum aut quasi doloremque suscipit porro fugit. Voluptatibus blanditiis dolore quasi quidem.', '2007-07-26', 31, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(80, 9, 3, 'Modi porro dolor voluptas quae tenetur. Dolor officiis magnam cum cum commodi beatae aperiam. Voluptatum quisquam et minus in magnam quia.', '1988-07-17', 4, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(81, 6, 2, 'Perferendis sed ut laudantium tenetur est ea. Maiores nihil est est quia sunt praesentium at.', '1977-06-23', 1, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(82, 7, 2, 'Magni culpa culpa eius explicabo. Magni et consequatur eos sequi.', '1971-06-06', 78, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(83, 3, 8, 'Perspiciatis eaque rem praesentium sequi ea est non modi. Mollitia ipsam consequatur dolorem eos sed.', '2013-10-23', 40, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(84, 5, 4, 'Est et facilis ut est accusamus eligendi. Ut tenetur qui ut ratione. Tempore occaecati rerum dicta qui pariatur cupiditate tempora.', '1992-08-09', 12, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(85, 8, 5, 'Excepturi dolore voluptatem earum cumque omnis illum. Suscipit reprehenderit et fugiat repudiandae perferendis et quia.', '2017-12-25', 94, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(86, 6, 3, 'Vero quia dolores aut ad autem. Esse et consequatur aspernatur et sequi. Modi similique autem earum tempora quia est praesentium voluptate.', '2023-10-01', 17, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(87, 4, 1, 'Aliquid delectus non eligendi saepe quia adipisci. Voluptas sunt accusantium qui quos.', '2016-02-15', 100, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(88, 10, 7, 'Iure voluptatem occaecati est aut quia fugit voluptas. Saepe totam fugit animi esse est placeat deserunt illum. Tenetur iusto et molestias quas corporis ut.', '2006-06-28', 14, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(89, 10, 9, 'Quia deleniti non aut. Quis minima sed rerum. Ea earum adipisci libero.', '1977-12-30', 69, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(90, 10, 10, 'Incidunt eos corrupti rerum et et labore quasi. Ut voluptatem itaque ullam est impedit. Beatae eos ipsam autem unde adipisci.', '2006-03-20', 16, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(91, 4, 1, 'Architecto omnis eaque qui voluptas molestiae velit. Incidunt ab fuga itaque tempore amet labore. Quisquam et officiis non quae.', '1976-12-05', 70, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(92, 2, 8, 'Et voluptatem maxime sit. Est at quo eos repellat est nam eveniet. Et maiores temporibus amet delectus est.', '2017-06-18', 7, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(93, 10, 5, 'Odio ad voluptatem quam provident. Labore corrupti nemo optio distinctio facere.', '1977-10-10', 33, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(94, 2, 9, 'Qui in alias suscipit reprehenderit eos perspiciatis. Sit nam aperiam cupiditate quia sunt. Sed qui qui et quas sunt voluptas.', '1975-04-14', 29, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(95, 6, 10, 'Qui error enim cumque dicta ut. Non hic vel est sed.', '2014-03-07', 27, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(96, 7, 4, 'Quia eos repudiandae quis fugit. Distinctio ab commodi magni impedit non id qui. Ullam voluptatem accusantium quisquam error voluptatem veniam accusantium et.', '1990-10-12', 9, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(97, 10, 4, 'Nam libero tempora est corrupti. Nemo eos ipsa tempore nesciunt.', '1975-12-25', 75, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(98, 8, 8, 'Natus consequatur placeat voluptatum iste nihil. Aut ut non occaecati dolorem explicabo provident quibusdam. Occaecati aliquid illo fugit ut sed quo.', '2019-10-05', 97, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(99, 4, 1, 'Delectus excepturi maxime molestiae vitae optio. Non repellendus autem odio modi velit quasi.', '1982-11-23', 94, '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(100, 1, 9, 'Ad quia maxime culpa. Officiis iste perferendis omnis eligendi magnam nobis dolorum. Hic neque amet aut modi.', '2024-08-15', 92, '2025-03-17 01:51:48', '2025-03-17 01:51:48');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Mina', 'Alfy', 'minaalfy8@gmail.com', '2025-03-17 01:51:48', '$2y$12$.sVSuQhlU7XDFebhM9LCA.osIzkxIrVIUzzwuRRwgRtZ3thyKkJmu', 'hqTpwNTz2g', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(2, 'Dora', 'Little', 'predovic.everett@example.org', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'u6BUp6yuQa', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(3, 'Eldon', 'Schaden', 'celia.spencer@example.net', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'wArGivoXem', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(4, 'Lorenza', 'Gerhold', 'fschneider@example.net', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'B2Z6rWS7GU', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(5, 'Clifford', 'Kihn', 'agoyette@example.com', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'IyGBcyOYkg', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(6, 'Misael', 'Bahringer', 'jess.turner@example.org', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'P2T5HOt52P', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(7, 'Perry', 'Cartwright', 'houston.ledner@example.net', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'xgzxKSJXlc', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(8, 'Miller', 'Frami', 'whoeger@example.org', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'XQgASZkq57', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(9, 'Norberto', 'Mayer', 'millie.ferry@example.com', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'lZZeFGYrC0', '2025-03-17 01:51:48', '2025-03-17 01:51:48'),
(10, 'Donavon', 'Marquardt', 'glover.treva@example.net', '2025-03-17 01:51:48', '$2y$12$GdAQNlnTNvTNozVPFHYNaOyK7DUyO/WWy2yA044s8RGYzvNBa4Ire', 'z6m4cHRFuH', '2025-03-17 01:51:48', '2025-03-17 01:51:48');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attributes`
--
ALTER TABLE `attributes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `attributes_slug_unique` (`slug`);

--
-- Indexes for table `attributes_options`
--
ALTER TABLE `attributes_options`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attributes_options_attribute_id_foreign` (`attribute_id`);

--
-- Indexes for table `attribute_boolean_values`
--
ALTER TABLE `attribute_boolean_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_boolean_values_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  ADD KEY `attribute_boolean_values_index` (`attribute_id`,`entity_id`,`entity_type`),
  ADD KEY `attribute_boolean_values_content_index` (`content`);

--
-- Indexes for table `attribute_datetime_values`
--
ALTER TABLE `attribute_datetime_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_datetime_values_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  ADD KEY `attribute_datetime_values_index` (`attribute_id`,`entity_id`,`entity_type`),
  ADD KEY `attribute_datetime_values_content_index` (`content`);

--
-- Indexes for table `attribute_date_values`
--
ALTER TABLE `attribute_date_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_date_values_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  ADD KEY `attribute_date_values_attribute_id_foreign` (`attribute_id`);

--
-- Indexes for table `attribute_entity`
--
ALTER TABLE `attribute_entity`
  ADD PRIMARY KEY (`attribute_id`),
  ADD UNIQUE KEY `attributable_attribute_id_entity_type` (`attribute_id`,`entity_type`),
  ADD KEY `attribute_entity_entity_type_entity_id_index` (`entity_type`,`entity_id`);

--
-- Indexes for table `attribute_integer_values`
--
ALTER TABLE `attribute_integer_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_integer_values_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  ADD KEY `attribute_integer_values_index` (`attribute_id`,`entity_id`,`entity_type`),
  ADD KEY `attribute_integer_values_content_index` (`content`);

--
-- Indexes for table `attribute_select_values`
--
ALTER TABLE `attribute_select_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_select_values_content_foreign` (`content`),
  ADD KEY `attribute_select_values_attribute_id_foreign` (`attribute_id`),
  ADD KEY `attribute_select_values_entity_type_entity_id_index` (`entity_type`,`entity_id`);

--
-- Indexes for table `attribute_text_values`
--
ALTER TABLE `attribute_text_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_text_values_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  ADD KEY `attribute_text_values_index` (`attribute_id`,`entity_id`,`entity_type`);

--
-- Indexes for table `attribute_varchar_values`
--
ALTER TABLE `attribute_varchar_values`
  ADD PRIMARY KEY (`id`),
  ADD KEY `attribute_varchar_values_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  ADD KEY `attribute_varchar_values_index` (`attribute_id`,`entity_id`,`entity_type`),
  ADD KEY `attribute_varchar_values_content_index` (`content`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_user`
--
ALTER TABLE `project_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `project_user_user_id_project_id_unique` (`user_id`,`project_id`),
  ADD KEY `project_user_project_id_foreign` (`project_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `timesheet_logs`
--
ALTER TABLE `timesheet_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `timesheet_logs_user_id_foreign` (`user_id`),
  ADD KEY `timesheet_logs_project_id_foreign` (`project_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attributes`
--
ALTER TABLE `attributes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attributes_options`
--
ALTER TABLE `attributes_options`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attribute_boolean_values`
--
ALTER TABLE `attribute_boolean_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attribute_datetime_values`
--
ALTER TABLE `attribute_datetime_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attribute_date_values`
--
ALTER TABLE `attribute_date_values`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `attribute_entity`
--
ALTER TABLE `attribute_entity`
  MODIFY `attribute_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attribute_integer_values`
--
ALTER TABLE `attribute_integer_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attribute_select_values`
--
ALTER TABLE `attribute_select_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `attribute_text_values`
--
ALTER TABLE `attribute_text_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `attribute_varchar_values`
--
ALTER TABLE `attribute_varchar_values`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `project_user`
--
ALTER TABLE `project_user`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `timesheet_logs`
--
ALTER TABLE `timesheet_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attributes_options`
--
ALTER TABLE `attributes_options`
  ADD CONSTRAINT `attributes_options_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_boolean_values`
--
ALTER TABLE `attribute_boolean_values`
  ADD CONSTRAINT `attribute_boolean_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_datetime_values`
--
ALTER TABLE `attribute_datetime_values`
  ADD CONSTRAINT `attribute_datetime_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_date_values`
--
ALTER TABLE `attribute_date_values`
  ADD CONSTRAINT `attribute_date_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_entity`
--
ALTER TABLE `attribute_entity`
  ADD CONSTRAINT `attribute_entity_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_integer_values`
--
ALTER TABLE `attribute_integer_values`
  ADD CONSTRAINT `attribute_integer_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_select_values`
--
ALTER TABLE `attribute_select_values`
  ADD CONSTRAINT `attribute_select_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `attribute_select_values_content_foreign` FOREIGN KEY (`content`) REFERENCES `attributes_options` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_text_values`
--
ALTER TABLE `attribute_text_values`
  ADD CONSTRAINT `attribute_text_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `attribute_varchar_values`
--
ALTER TABLE `attribute_varchar_values`
  ADD CONSTRAINT `attribute_varchar_values_attribute_id_foreign` FOREIGN KEY (`attribute_id`) REFERENCES `attributes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `project_user`
--
ALTER TABLE `project_user`
  ADD CONSTRAINT `project_user_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `project_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `timesheet_logs`
--
ALTER TABLE `timesheet_logs`
  ADD CONSTRAINT `timesheet_logs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `timesheet_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
